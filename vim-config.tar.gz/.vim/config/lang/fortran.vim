" findent fortran config
let use_findent = 1
let use_findent_indentexpr = 1
let findent_flags = "-i4"
let findent = "findent"

" VIM fortran indent config
" let fortran_do_enddo=1
" let fortran_more_precise=1
let fortran_fold=1
let fortran_fold_conditionals=1


" align var definition
vnoremap <leader>; :s/^\(.\{-}\)\s*::\s*/\=printf("%-43s :: ",submatch(1))<CR>:noh<CR>
nnoremap <leader>; V<CR>:s/^\(.\{-}\)\s*::\s*/\=printf("%-43s :: ",submatch(1))<CR>:noh<CR>
nnoremap <leader>: :%s/^\%(.*::\s*&\s*$\)\@!\(\s*\%(real\|integer\|logical\|type(\|class(\|procedure\|generic\|import\).\{-}\)\s*::\s*/\=printf("%-43s :: ",submatch(1))<CR>:noh<CR>

" fprettify format-on-save — filter the buffer in place; DO NOT :edit! during BufWritePre
augroup FORTRAN_FT
  autocmd!
  autocmd BufWritePre *.f90,*.F90 if executable('fprettify') |
        \   execute 'keepjumps keeppatterns %!fprettify --indent 4 -' |
        \ endif
augroup END

" tagbar Fortran redefinition
let g:tagbar_type_fortran = {
    \ 'ctagstype' : 'fortran',
    \ 'kinds'     : [
        \ 'S:submodules:1:1',
        \ 'v:global variables:1:1',
        \ 't:derived types:1:1',
        \ 'M:type bound procedures:1:1',
        \ 'k:type variables:1:1',
        \ 'i:interfaces:0:1',
        \ 'P:procedure prototypes:0:1',
        \ 'E:enumerations:1:1',
        \ 'N:enumeration values:1:1',
        \ 'p:programs:1:1',
        \ 'f:functions:1:1',
        \ 's:subroutines:1:1',
        \ 'b:block data:1:0',
        \ 'c:common blocks:1:1',
        \ 'e:entry points:1:1',
        \ 'l:labels:1:1',
        \ 'n:namelists:1:1',
    \ ],
    \ 'sro'       : '%',
    \ 'kind2scope': {
        \ 't' : 'type',
    \ },
    \ 'scope2kind': {
        \ 'type'       : 't',
    \ },
    \ 'sort'      : 0,
\ }
