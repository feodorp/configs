" Format JSON with jq (falls back to python if jq missing)
if executable('jq')
  autocmd FileType json nnoremap <buffer> <leader>= :%!jq .<CR>
  autocmd FileType json vnoremap <buffer> <leader>= :!jq .<CR>
elseif executable('python3')
  autocmd FileType json nnoremap <buffer> <leader>= :%!python3 -m json.tool<CR>
  autocmd FileType json vnoremap <buffer> <leader>= :!python3 -m json.tool<CR>
endif
