" --- MATLAB style preferences (edit these to change format style) -----------
let g:matlab_line_length = 120
let g:matlab_tab_width   = 4

" --- Filetype defaults -------------------------------------------------------
augroup MATLAB_FT
  autocmd!
  autocmd FileType matlab execute 'setlocal shiftwidth=' . g:matlab_tab_width
  autocmd FileType matlab execute 'setlocal softtabstop=' . g:matlab_tab_width
  autocmd FileType matlab execute 'setlocal tabstop=' . g:matlab_tab_width
  autocmd FileType matlab execute 'setlocal colorcolumn=' . g:matlab_line_length
  autocmd FileType matlab setlocal expandtab textwidth=0
  autocmd FileType matlab setlocal commentstring=%\ %s
  autocmd FileType matlab setlocal foldmethod=indent

  " <Leader>ff — manual reformat, parity with C++ ClangFormat mapping
  autocmd FileType matlab nnoremap <buffer><Leader>ff
        \ :call <SID>MatlabFormat()<CR>
  autocmd FileType matlab vnoremap <buffer><Leader>ff
        \ :call <SID>MatlabFormat()<CR>

  " mh_style format-on-save. miss-hit has no stdin mode; --fix rewrites the
  " saved file in place, so this runs in BufWritePost and reloads the buffer.
  autocmd BufWritePost *.m call <SID>MatlabFormat()
augroup END

" Build and run the mh_style command from the Vim style variables.
" Passing --line_length and --tab_width on the CLI means style is controlled
" from this file, not from any miss_hit.cfg.
function! s:MatlabFormat() abort
  if !executable('mh_style')
    return
  endif
  let l:cmd = printf('mh_style --line_length %d --tab_width %d --fix %s >/dev/null 2>&1',
        \ g:matlab_line_length,
        \ g:matlab_tab_width,
        \ shellescape(expand('%')))
  silent! execute '!' . l:cmd
  silent! edit!
endfunction

" Tagbar outline using the three kinds Universal Ctags 6.x exposes for MATLAB:
"   f function, v variable, c class
let g:tagbar_type_matlab = {
    \ 'ctagstype' : 'matlab',
    \ 'kinds'     : [
        \ 'c:classes',
        \ 'f:functions',
        \ 'v:variables',
    \ ],
    \ 'sort' : 0,
\ }
