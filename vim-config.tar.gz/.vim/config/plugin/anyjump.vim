let g:any_jump_disable_default_keybindings = 1
let g:any_jump_list_numbers = 1

nnoremap <leader>j :call Preserve("AnyJump")<CR>
xnoremap <leader>j :call Preserve("AnyJump")<CR>
