augroup FSWITCH_RULES
  autocmd!
  autocmd BufEnter *.hpp let b:fswitchdst  = 'cpp,cc'
  autocmd BufEnter *.hpp let b:fswitchlocs = 'reg:/include/src/,reg:/include.*/src/'
  autocmd BufEnter *.h   let b:fswitchdst  = 'c,cpp,cc,C'
  autocmd BufEnter *.h   let b:fswitchlocs = 'reg:/include/src/,reg:/include.*/src/'
augroup END

nnoremap <silent> <leader>1 :FSHere<cr>
