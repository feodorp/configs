" List files via ripgrep (includes hidden, ignores .git)
if executable('rg')
  let $FZF_DEFAULT_COMMAND = 'rg --files --hidden --follow --glob "!.git/*"'
endif

" Convenience commands with preview — defined after VimEnter so
" fzf.vim's autoload functions are loadable.
augroup FZF_CUSTOM_CMDS
  autocmd!
  autocmd VimEnter * command! -nargs=* Rg call fzf#vim#grep(
        \ 'rg --vimgrep --hidden --follow --glob "!.git/*" '.shellescape(<q-args>),
        \ 1, fzf#vim#with_preview(), 0)
  autocmd VimEnter * command! -nargs=? Files call fzf#vim#files(<q-args>, fzf#vim#with_preview(), 0)
augroup END

" Keymaps
nnoremap <C-p>     :Files<CR>
nnoremap <leader>f :Files<CR>
nnoremap <leader>b :Buffers<CR>
nnoremap <leader>l :Lines<CR>
nnoremap <leader>g :Rg<Space>
