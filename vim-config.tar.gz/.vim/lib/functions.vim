" ----------------------------------------
" Functions
" ----------------------------------------

" ---------------
" Convert Ruby 1.8 hash rockets to 1.9 JSON style hashes.
" From: http://git.io/cxmJDw
" Note: Defaults to the entire file unless in visual mode.
" ---------------
command! -bar -range=% NotRocket execute '<line1>,<line2>s/:\(\w\+\)\s*=>/\1:/e' . (&gdefault ? '' : 'g')

" ---------------
" Strip Trailing White Space
" ---------------
" From http://vimbits.com/bits/377
" Preserves/Saves the state, executes a command, and returns to the saved state
function! Preserve(command)
  " Preparation: save last search, and cursor position.
  let l:_s = getreg('/')
  let l:l = line('.')
  let l:c = col('.')
  " Do the business:
  execute a:command
  " Clean up: restore previous search history, and cursor position
  call setreg('/', l:_s)
  call cursor(l:l, l:c)
endfunction
"strip all trailing white space
command! StripTrailingWhiteSpace call Preserve('%s/\s\+$//e')

" ---------------
" Quick spelling fix (first item in z= list)
" ---------------
function! QuickSpellingFix()
  if &spell
    normal! 1z=
  else
    " Enable spelling mode and do the correction
    set spell
    normal! 1z=
    set nospell
  endif
endfunction

command! QuickSpellingFix call QuickSpellingFix()

" ---------------
" MPage follow-mode toggle.
" On entry, save current wrap/linebreak/breakindent on this window, enable
" wrap+linebreak+breakindent so long lines stay visible inside narrow columns,
" then run :NMPage to split into N columns. New splits inherit window-local
" options, so wrap propagates to all panes.
" On exit, :MPage! turns multipaging off in every window in the current tab,
" then we restore the saved wrap state on the surviving window.
" Bound to <Leader>v3 / <Leader>v1 in vimrc.local.
" ---------------
function! MPageOn(n) abort
  let s:mpage_saved = {'wrap': &l:wrap,
        \              'linebreak': &l:linebreak,
        \              'breakindent': &l:breakindent}
  setlocal wrap linebreak breakindent
  execute a:n . 'MPage'
endfunction

function! MPageOff() abort
  MPage!
  if exists('s:mpage_saved')
    let &l:wrap        = s:mpage_saved.wrap
    let &l:linebreak   = s:mpage_saved.linebreak
    let &l:breakindent = s:mpage_saved.breakindent
    unlet s:mpage_saved
  endif
endfunction

