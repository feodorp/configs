call plug#begin('~/.vim/plugged')

" ---------- Navigation / project ----------
Plug 'preservim/tagbar'                         " code outline (ctags)
Plug 'scrooloose/nerdtree'                      " project drawer
Plug 'tpope/vim-vinegar'                        " nicer netrw ('-')
Plug 'tpope/vim-projectionist'                  " project alt files (src<->test)
Plug 'pechorin/any-jump.vim'                    " jump to definition
Plug 'tpope/vim-surround'                       " quoting/parenthesizing made simple
Plug 'tpope/vim-eunuch'                         " UNIX shell commands

" ---------- Fuzzy finder (ripgrep-backed) ----------
Plug 'junegunn/fzf',     { 'do': { -> fzf#install() } }
Plug 'junegunn/fzf.vim'

" ---------- Themes ----------
Plug 'morhetz/gruvbox'
Plug 'mhartington/oceanic-next'
Plug 'ayu-theme/ayu-vim'
Plug 'crusoexia/vim-monokai'
Plug 'NLKNguyen/papercolor-theme'

" ---------- Statusline ----------
Plug 'vim-airline/vim-airline'
Plug 'vim-airline/vim-airline-themes'

" ---------- Build / tags ----------
Plug 'tpope/vim-dispatch'                       " async :Make, :Dispatch
Plug 'ludovicchabant/vim-gutentags'             " auto ctags regeneration
Plug 'editorconfig/editorconfig-vim'            " respect .editorconfig files

" ---------- Editing QoL ----------
Plug 'airblade/vim-gitgutter'                   " git diff signs in gutter
Plug 'ntpeters/vim-better-whitespace'           " trailing space highlight
Plug 'tpope/vim-fugitive'                       " :Git wrapper
Plug 'tpope/vim-rhubarb'
Plug 'tomtom/tcomment_vim'                      " comment toggling
Plug 'mbbill/undotree'                          " visual undo tree
Plug 'andymass/vim-matchup'                     " modern matchit (% over constructs)
Plug 'wellle/targets.vim'                       " extra text-objects
Plug 'kana/vim-textobj-user'                    " base for custom text objects
Plug 'lucapette/vim-textobj-underscore'         " a_ / i_ word parts
Plug 'saaguero/vim-textobj-pastedtext'          " last paste textobj
Plug 'kana/vim-textobj-function'                " function textobj
Plug 'kana/vim-textobj-fold'                    " fold textobj
Plug 'drmikehenry/vim-headerguard'              " header guards

" ---------- Snippets ----------
if has('python') || has('python3')
  Plug 'SirVer/ultisnips'                       " engine
  Plug 'honza/vim-snippets'                     " community snippets
endif

" ---------- LSP / completion ----------
Plug 'prabirshrestha/vim-lsp'                   " LSP client
Plug 'mattn/vim-lsp-settings'                   " auto bootstrap servers
Plug 'prabirshrestha/asyncomplete.vim'          " completion popup
Plug 'prabirshrestha/asyncomplete-lsp.vim'      " LSP source for asyncomplete

" ---------- Debugger ----------
Plug 'puremourning/vimspector'

" ---------- C/C++ helpers ----------
Plug 'rhysd/vim-clang-format', { 'for': ['c','cpp','objc','objcpp'] }
Plug 'derekwyatt/vim-fswitch',  { 'for': ['c','cpp','objc','objcpp'] }
Plug 'bfrg/vim-cpp-modern',     { 'for': ['c','cpp'] }

" ---------- Fortran ----------
Plug g:plug_home.'/findent'

" ---------- Markdown / Pandoc ----------
Plug 'vim-pandoc/vim-pandoc'
Plug 'vim-pandoc/vim-pandoc-syntax'

" ---------- LaTeX ----------
Plug 'lervag/vimtex',           { 'for': 'tex' }

call plug#end()
