" --- Initialization ----------------------------------------------------------
set nocompatible              " Use Vim (not vi) behavior
set encoding=utf-8            " UI/messages/file default encoding

filetype plugin indent on     " Filetype detection, ftplugins, auto-indent
syntax enable                 " Syntax highlighting

" --- UI / Behavior -----------------------------------------------------------
set hidden                    " Switch buffers without saving
set number                    " Show line numbers
set numberwidth=4             " Width of the line number column
set signcolumn=yes            " Reserve gutter for diagnostics/git signs
set cursorline                " Highlight current line
set nowrap                    " Do not soft-wrap long lines
set updatetime=300            " Snappier CursorHold (LSP, git signs updates)
set mouse=a                   " Enable mouse in all modes
set confirm                   " Ask instead of erroring on :q with changes
set cmdheight=2               " More space for messages/commands
set noshowmode                " Airline/statusline shows mode already
set lazyredraw                " Faster macros/substitutions (skip mid-redraw)

" --- Search UX ---------------------------------------------------------------
set ignorecase                " Case-insensitive search by default...
set smartcase                 " ...but case-sensitive if pattern has capitals
set incsearch                 " Show matches while typing
set hlsearch                  " Highlight search matches

" --- Indentation defaults (languages can override in config/lang/*) ---------
set expandtab                 " Insert spaces when pressing <Tab>
set shiftwidth=4              " Indentation step
set softtabstop=4             " A <Tab> feels like 4 spaces in Insert mode
set tabstop=4                 " Display width of actual <Tab> characters

" --- Completion popup UX -----------------------------------------------------
set completeopt=menuone,noinsert,noselect
set shortmess+=c              " Tidy completion messages

" --- Folding -----------------------------------------------------------------
set foldmethod=manual
set foldlevelstart=99         " Open all folds on file open

" --- Command-line completion & ignore patterns -------------------------------
set wildmode=list:longest,full
set wildignore+=.final_builds/*,*/node_modules/*,*.o,*.obj,*.exe,*.so,*.dll,*.pyc,.svn,.hg,.bzr,.git,.sass-cache,*.class,*.scssc,*/Godeps/*

" --- Autosave behavior -------------------------------------------------------
set autowrite

" --- Formatting --------------------------------------------------------------
set formatoptions=crql
set formatoptions+=j          " Smart comment joining

" --- Tags / Splits / Views ---------------------------------------------------
set tags=./tags;/,tags;/      " Search upward for tags files
set splitright                " Vertical splits open to the right
set viewoptions=cursor,folds,slash,unix

" --- Scrolling / Modelines ---------------------------------------------------
set scrolloff=3               " Keep N context lines above/below cursor
set nomodeline                " Ignore file-embedded modelines (security)

" --- Match / Bells -----------------------------------------------------------
set showmatch                 " Briefly jump to matching bracket
set noerrorbells
set novisualbell

" --- Persistent undo ---------------------------------------------------------
if has('persistent_undo')
  if !isdirectory($HOME.'/.vim/.undo')
    call mkdir($HOME.'/.vim/.undo', 'p')
  endif
  set undofile
  set undodir=~/.vim/.undo
endif

" --- Swap/Backup hygiene -----------------------------------------------------
if !isdirectory($HOME.'/.vim/.vim-tmp')
  call mkdir($HOME.'/.vim/.vim-tmp', 'p')
endif
set swapfile
set directory=~/.vim/.vim-tmp,~/tmp,/var/tmp,/tmp
set backupdir=~/.vim/.vim-tmp,~/tmp,/var/tmp,/tmp

" --- Netrw tweak -------------------------------------------------------------
let g:netrw_altfile = 1       " Prevent netrw buffers becoming 'alternate'

" --- Grep backend (prefer ripgrep if available) ------------------------------
if executable('rg')
  set grepprg=rg\ --vimgrep
endif

" --- Cursor shapes (Terminal & GUI) -----------------------------------------
if exists('+guicursor')
  set guicursor=n-v-c:block-Cursor-blinkon0,i-ci:ver25,r-cr:hor20,sm:block
endif

if !has('gui_running')
  let &t_SI = "\e[6 q"   " Start Insert: bar
  let &t_EI = "\e[2 q"   " End Insert:   block
endif
