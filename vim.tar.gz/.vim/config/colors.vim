set colorcolumn=132

let g:gruvbox_italic=1

let s:colors = getcompletion('', 'color')

function! PulseCursorLine()
    let current_window = winnr()

    windo set nocursorline
    execute current_window . 'wincmd w'

    setlocal cursorline

    redir => old_hi
    silent execute 'hi CursorLine'
    redir END
    let old_hi = split(old_hi, '\n')[0]
    let old_hi = substitute(old_hi, 'xxx', '', '')

    hi CursorLine guibg=#3a3a3a ctermbg=235
    redraw
    sleep 20m

    hi CursorLine guibg=#4a4a4a ctermbg=235
    redraw
    sleep 30m

    hi CursorLine guibg=#3a3a3a ctermbg=235
    redraw
    sleep 30m

    hi CursorLine guibg=#2a2a2a ctermbg=235
    redraw
    sleep 20m

    execute 'hi ' . old_hi

    windo set cursorline
    execute current_window . 'wincmd w'
endfunction

function! colors#_change(index)
  let l:idx = a:index
  if l:idx < 0
    let l:idx = len(s:colors) - 1
  elseif l:idx > len(s:colors) - 1
    let l:idx = 0
  endif

  let l:name = s:colors[l:idx]
  silent! execute 'colorscheme '.l:name
endfunction

function! colors#_callback()
  hi MatchParen cterm=underline ctermbg=DarkGray ctermfg=none gui=underline guifg=NONE guibg=NONE
endfunction

function! colors#next()
  let l:next_index = index(s:colors, g:colors_name) + 1
  call colors#_change(l:next_index)
endfunction

function! colors#prev()
  let l:prev_index = index(s:colors, g:colors_name) - 1
  call colors#_change(l:prev_index)
endfunction

function! colors#toggle_background()
  if &background ==# 'light'
    set background=dark
  else
    set background=light
  endif
endfunction

function! colors#peek()
  echo g:colors_name . ' - ' . &background
endfunction

command! ColorsPrev call colors#prev()
command! ColorsNext call colors#next()
command! ColorsToggleBG call colors#toggle_background()
command! ColorsPeek call colors#peek()

map <silent><F2> :ColorsPrev<cr>
map <silent><F3> :ColorsNext<cr>
map <silent><F4> :ColorsToggleBG<cr>
map <silent><F1> :ColorsPeek<cr>
set background=dark

if has('termguicolors')
  set termguicolors
  if &term =~# '^screen' || &term =~# '^tmux'
    let &t_8f = "\<Esc>[38;2;%lu;%lu;%lum"
    let &t_8b = "\<Esc>[48;2;%lu;%lu;%lum"
  endif
endif

" augroup my_colors
"   autocmd! ColorScheme * silent! call colors#_callback()
" augroup END
"
try
  colorscheme gruvbox
catch
endtry

