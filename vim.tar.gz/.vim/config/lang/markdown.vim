augroup markdown_ft
  autocmd!
  autocmd FileType pandoc setlocal spell | setlocal lbr | setlocal nonu
  autocmd FileType markdown setlocal spell | setlocal lbr | setlocal nonu
augroup END
