augroup PYTHON_FT
  autocmd!
  " Tabs/indent & soft wrap behavior
  autocmd FileType python setlocal expandtab shiftwidth=4 softtabstop=4 tabstop=4
  " Keep lines visible; colorcolumn marks 88 char guideline
  autocmd FileType python setlocal colorcolumn=88 textwidth=0
  " Folding that feels natural for Python blocks
  autocmd FileType python setlocal foldmethod=indent

  " Ruff formatter
  autocmd BufWritePre *.py if executable('ruff') |
        \   silent! execute 'keepjumps keeppatterns %!ruff format -q -' |
        \   edit! |
        \ endif
augroup END
