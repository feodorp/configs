let g:pandoc#syntax#conceal#use = 1
let g:pandoc#syntax#codeblocks#embeds#langs = ['python', 'cpp', 'c', 'fortran', 'bash=sh', 'vim', 'json', 'latex=tex']
let g:pandoc#folding#level = 3
let g:pandoc#folding#mode = 'stacked'
let g:pandoc#modules#disabled = ['spell']
let g:pandoc#formatting#mode = 'h'
