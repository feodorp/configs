let g:vimspector_enable_mappings = 'HUMAN'

" Handy mappings
nnoremap <silent> <leader>dd :call vimspector#Launch()<CR>
nnoremap <silent> <leader>de :call vimspector#Reset()<CR>
nnoremap <silent> <leader>db :call vimspector#ToggleBreakpoint()<CR>
nnoremap <silent> <leader>dB :call vimspector#ToggleConditionalBreakpoint()<CR>
