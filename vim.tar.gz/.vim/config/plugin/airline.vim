let g:airline_theme = 'tomorrow'
let g:airline_powerline_fonts = 0
if has('gui_running') && &guifont =~# 'Powerline'
  let g:airline_powerline_fonts = 1
endif

let g:airline#extensions = ['branch', 'netrw', 'tabline']
let g:airline#extensions#tabline#enabled = 1
let g:airline#extensions#tabline#formatter = 'unique_tail'
