function! g:HeaderguardName()
    return toupper(expand('%:t:gs/[^0-9a-zA-Z_]/_/g'))
endfunction
