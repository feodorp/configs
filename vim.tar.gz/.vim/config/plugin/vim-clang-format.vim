" c:lang_format#style_options = {
"        \ "AccessModifierOffset" : -4,
"        \ "AllowShortIfStatementsOnASingleLine" : "true",
"        \ "AlwaysBreakTemplateDeclarations" : "true",
"        \ "Standard" : "C++17"}

let g:clang_format#detect_style_file=1
" let g:clang_format#auto_format=1
let g:clang_format#auto_formatexpr=1
" let g:clang_format#auto_format_on_insert_leave=1


" map to <Leader>ff in C++ code
autocmd FileType c,cpp,objc nnoremap <buffer><Leader>ff :<C-u>ClangFormat<CR>
autocmd FileType c,cpp,objc vnoremap <buffer><Leader>ff :ClangFormat<CR>
" " if you install vim-operator-user
" autocmd FileType c,cpp,objc map <buffer><Leader>x
" <Plug>(operator-clang-format)
" " Toggle auto formatting:
" nmap <Leader>C :ClangFormatAutoToggle<CR>
