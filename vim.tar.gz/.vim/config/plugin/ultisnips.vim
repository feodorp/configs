let g:UltiSnipsSnippetDirectories       = [$HOME.'/.vim/UltiSnips']
let g:UltiSnipsEditSplit                = 'horizontal'
let g:UltiSnipsExpandTrigger            = '<C-j>'
let g:UltiSnipsJumpForwardTrigger       = '<C-j>'
let g:UltiSnipsJumpBackwardTrigger      = '<C-k>'
