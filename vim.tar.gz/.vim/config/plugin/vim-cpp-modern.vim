" Enable highlighting of C++ attributes
let g:cpp_attributes_highlight = 1

" Hihjlight struct/class membr variables (C and C++)
let g:cpp_member_highlight = 1
