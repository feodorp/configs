" -------- Diagnostics & UX --------
let g:lsp_signs_enabled             = 1
let g:lsp_sign_error                = '✘'
let g:lsp_sign_warning              = '▲'
let g:lsp_sign_information          = ''
let g:lsp_sign_hint                 = '•'
let g:lsp_diagnostics_echo_cursor   = 1

" -------- Servers --------
let g:lsp_settings = get(g:, 'lsp_settings', {})

" --- PYTHON ---
let g:lsp_settings['pyright'] = {
\ 'cmd': ['pyright-langserver', '--stdio'],
\ 'workspace_config': {
\   'python': {
\     'analysis': {
\       'typeCheckingMode': 'basic',
\       'autoImportCompletions': v:true
\     }
\   }
\ }
\}

let g:lsp_settings['ruff_lsp'] = {
\ 'cmd': ['ruff-lsp'],
\ 'allowlist': ['python']
\}

" --- C/C++ ---
let g:lsp_settings['clangd'] = {
\ 'cmd': ['clangd', '--background-index', '--header-insertion=never'],
\ 'allowlist': ['c','cpp','objc','objcpp']
\}

" --- FORTRAN ---
let g:lsp_settings['fortls'] = {
\ 'cmd': ['fortls', '--lowercase_intrinsics'],
\ 'allowlist': ['fortran']
\}

" -------- Keymaps on LSP attach (buffer-local) --------
augroup LSP_KEYS
  autocmd!
  autocmd User lsp_buffer_enabled call s:lsp_maps()
augroup END

function! s:lsp_maps() abort
  nnoremap <buffer> gd :LspDefinition<CR>
  nnoremap <buffer> gD :LspPeekDefinition<CR>
  nnoremap <buffer> gr :LspReferences<CR>
  nnoremap <buffer> K  :LspHover<CR>
  nnoremap <buffer> rn :LspRename<CR>
  nnoremap <buffer> [d :LspPreviousDiagnostic<CR>
  nnoremap <buffer> ]d :LspNextDiagnostic<CR>
  nnoremap <buffer> <leader>ca :LspCodeAction<CR>
endfunction
