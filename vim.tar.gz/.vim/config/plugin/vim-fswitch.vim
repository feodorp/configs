au BufEnter *.hpp let b:fswitchdst  = 'cpp,cc'
au BufEnter *.hpp let b:fswitchlocs = 'reg:/include/src/,reg:/include.*/src/'
au BufEnter *.h let b:fswitchdst  = 'c,cpp,cc,C'
au BufEnter *.h let b:fswitchlocs = 'reg:/include/src/,reg:/include.*/src/'

nnoremap <silent> <leader>1 :FSHere<cr>
