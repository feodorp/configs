let g:gitgutter_sign_added            = '+'
let g:gitgutter_sign_modified         = '~'
let g:gitgutter_sign_removed          = '_'
let g:gitgutter_sign_modified_removed = '≃'
let g:gitgutter_map_keys              = 0   " we use our own mappings (none here)
