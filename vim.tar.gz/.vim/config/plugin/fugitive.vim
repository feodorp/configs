nnoremap <leader>gs :Git<cr>
nnoremap <leader>gb :Git blame<cr>
nnoremap <leader>gd :Gdiffsplit<cr>
nnoremap <leader>gg :GBrowse<cr>
nnoremap <leader>gl :Git log<cr>
