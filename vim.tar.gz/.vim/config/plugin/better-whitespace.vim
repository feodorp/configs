let g:better_whitespace_operator='_s'
let g:strip_whitespace_on_save=1
let g:strip_whitespace_confirm=0

