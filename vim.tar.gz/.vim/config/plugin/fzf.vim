" List files via ripgrep (includes hidden, ignores .git)
if executable('rg')
  let $FZF_DEFAULT_COMMAND = 'rg --files --hidden --follow --glob "!.git/*"'
endif

" Convenience commands with preview
if exists('*fzf#vim#grep')
  command! -nargs=* Rg   call fzf#vim#grep(
        \ 'rg --vimgrep --hidden --follow --glob "!.git/*" '.shellescape(<q-args>),
        \ 1, fzf#vim#with_preview(), 0)
  command! -nargs=? Files call fzf#vim#files(<q-args>, fzf#vim#with_preview(), 0)
endif

" Keymaps
nnoremap <C-p>     :Files<CR>
nnoremap <leader>f :Files<CR>
nnoremap <leader>b :Buffers<CR>
nnoremap <leader>l :Lines<CR>
nnoremap <leader>g :Rg<Space>
