let g:gutentags_ctags_executable = '/opt/homebrew/bin/ctags'
let g:gutentags_cache_dir = expand('~/.vim/.tags-cache')
let g:gutentags_generate_on_write = 1
let g:gutentags_generate_on_new = 1
